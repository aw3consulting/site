---
layout: page
title: About
permalink: /about/
---

# About AW3

AW3 Consulting is a boutique firm with global manufacturing and sourcing expertise.
