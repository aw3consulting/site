---
layout: page
title: Privacy Policy
permalink: /legal/privacy-policy.html
---

# Privacy Policy

We value your privacy. No personal data is collected without consent.
